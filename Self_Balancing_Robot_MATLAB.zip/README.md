# Self-Balancing Robot using MATLAB & Simulink (LQR Control)

An inverted-pendulum based Self-Balancing Robot dynamic modeling and control system simulation developed in MATLAB & Simulink using Linear Quadratic Regulator (LQR).

## 📌 Project Overview
* **System Model:** Inverted Pendulum on a Cart
* **Control Algorithm:** Full-State Feedback via LQR Matrix Calculation
* **Tools Used:** MATLAB R2023b / Simulink

## 🧮 Mathematical Model & State Variables
State Vector: $x = [x, \dot{x}, \theta, \dot{\theta}]^T$
* $x$: Position of the robot (m)
* $\dot{x}$: Linear velocity (m/s)
* $\theta$: Tilt angle from vertical (rad)
* $\dot{\theta}$: Angular velocity (rad/s)

## 🚀 How to Run
1. Open MATLAB and run `setup_robot.m` to load system matrices ($A, B, C, D$) and LQR Gain ($K$) into the workspace.
2. Open your Simulink model file (`robot_model.slx`).
3. Set simulation stop time to `10.0` seconds.
4. Click **Run** and open the **Scope** block to view system stability plots.

## 📊 Simulation Results
The LQR controller stabilizes the robot from an initial tilt perturbation of $\theta = 0.1\text{ rad}$ (approx $5.7^\circ$) back to the vertical equilibrium ($0\text{ rad}$) within $1.5 - 2$ seconds.
