% =========================================================================
% Self-Balancing Robot Controller Design using LQR (State-Space Approach)
% =========================================================================
% Project: Self-Balancing Robot (Inverted Pendulum Model)
% Author: Self-Balancing Robot Simulation Project
% Tools: MATLAB & Simulink
% =========================================================================

clear; clc; close all;

%% 1. Physical Parameters of the Robot
M = 1.2;    % Mass of the cart/wheels base (kg)
m = 0.35;   % Mass of the robot upper body (kg)
b = 0.1;    % Coefficient of friction for cart motion (N/m/s)
l = 0.25;   % Distance from wheel axis to center of mass (m)
I = 0.015;  % Mass moment of inertia of body (kg*m^2)
g = 9.81;   % Acceleration due to gravity (m/s^2)

%% 2. Continuous State-Space Representation
% State vector x = [x; x_dot; theta; theta_dot]
% x     : Position of the cart (m)
% x_dot : Velocity of the cart (m/s)
% theta : Tilt angle of body from vertical (rad)
% theta_dot : Angular velocity of body (rad/s)

p = I*(M + m) + M*m*l^2; % Denominator term

A = [0,                    1,                       0, 0;
     0, -(I + m*l^2)*b / p,       (m^2*g*l^2) / p, 0;
     0,                    0,                       0, 1;
     0,         -(m*l*b) / p, (m*g*l*(M + m)) / p, 0];

B = [0;
     (I + m*l^2) / p;
     0;
     (m*l) / p];

C = eye(4);      % Measure all four state variables
D = zeros(4, 1); % Direct transmission matrix

%% 3. Controllability Check
Co = ctrb(A, B);
if rank(Co) == 4
    disp('System status: CONTROLLABLE (Full-state feedback possible)');
else
    error('System status: NOT CONTROLLABLE');
end

%% 4. Linear Quadratic Regulator (LQR) Synthesis
% Weighting matrices
% Q prioritizes state deviations: [Position, Velocity, Angle, Angular Velocity]
Q = diag([100, 1, 500, 10]); 

% R penalizes control effort (Motor Voltage/Force)
R = 0.01; 

% Compute optimal gain vector K (u = -K*x)
K = lqr(A, B, Q, R);

disp('----------------------------------------------------');
disp('Calculated LQR Feedback Gain Matrix K:');
disp(K);
disp('----------------------------------------------------');
disp('Script execution complete! All workspace variables (A, B, C, D, K) loaded.');
